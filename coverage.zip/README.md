## React Countdown Timer

### Running the application

```sh
$ npm install
$ webpack
$ npm start
```
