module.exports = {
  verbose: true,
  modulePaths: [
    "__stubs__"
  ],
  testEnvironment: 'node',

 "moduleFileExtensions": [
        "js",
        "jsx",
        "node",
        "json"
    ],
    "moduleNameMapper": {
        "Clock": "<rootDir>/app/components/Clock.jsx",
        "CountdownForm": "<rootDir>/app/components/CountdownForm.jsx",
        "Countdown": "<rootDir>/app/components/Countdown.jsx"
    }
}