module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "assets/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	/** @jsx React.DOM */

	var React = __webpack_require__(1);

	var Application = __webpack_require__(2);

	var styleCollector = __webpack_require__(3);

	module.exports = function(req, scriptFilename) {

		var html;
		var css = styleCollector.collect(function() {
			html = React.renderComponentToString(Application( {url:req.url}));
		});
		return React.renderComponentToString(
			React.DOM.html(null, 
				React.DOM.head(null, 
					React.DOM.style( {id:"server-side-style", dangerouslySetInnerHTML:{__html: css}} )
				),
				React.DOM.body(null, 
					React.DOM.div( {id:"content"}),
					React.DOM.script( {src:"assets/" + scriptFilename})
				)
			)
		);
	}

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = require("react");

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	/** @jsx React.DOM */

	var React = __webpack_require__(1);

	var Application = React.createClass({displayName: 'Application',
		render: function() {
			__webpack_require__(4);
			return (
				React.DOM.div( {className:"application"}, 
					React.DOM.h1(null, "Hello World"),
					React.DOM.pre(null, this.props.url),
					React.DOM.img( {src:__webpack_require__(6), height:"100"} ),
					React.DOM.img( {src:__webpack_require__(7), height:"100"} )
				)
			);
		}
	});

	module.exports = Application;

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	exports.collect = function(fn) {
		var stuff = [];
		function add(css) {
			stuff.push(css);
		}
		var old = exports.add;
		exports.add = add;
		fn();
		exports.add = old;
		return stuff.join("\n");
	}

	exports.add = function() {}

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(3).add(__webpack_require__(5));
	delete __webpack_require__.c[module.id];

/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	module.exports =
		".application {\n\tborder: 1px solid blue;\n\tbackground: url("+__webpack_require__(6)+"), url("+__webpack_require__(7)+");\n}";

/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAIAAAAmkwkpAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAlSURBVBhXYzix//nMm6+AJBAxAFkIDhD/X3cSiIBCUGUgyf3PAeejJoXynSD8AAAAAElFTkSuQmCC"

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__.p + "59e68da5e8cbc0ba28bd706801d425ba.jpg"

/***/ }
/******/ ])